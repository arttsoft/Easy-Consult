# Setup

Install `mongodb`. In root folder run `yarn`.

Rename `env-sample` to `.env` and change it to your liking.