import nodemailer from "nodemailer";
import URI from "./middlewares/Config";
// import express from "express";

const from = '"Easy Consult" <info@easyconsult.com>';

function setup() {
  return nodemailer.createTransport({
    host: URI.EMAIL_HOST,
    port: URI.EMAIL_PORT,
    secure: URI.EMAIL_SECURE,
    auth: {
      user: URI.EMAIL_USER,
      pass: URI.EMAIL_PASS,
      authentication: URI.AUTHO
    },
    tls: {
        rejectUnauthorized: URI.EMAIL_REJECT
        }
  });
}

export function sendConfirmationEmail(user) {
  const tranport = setup();
  const email = {
    from:URI.EMAIL_USER_Name,
    to: user.email,
    subject: "Welcome to Easy Consult",
    html: `
    Welcome to Easy Consult. Please
    <a href=${user.generateConfirmationUrl()} > confirm</a> your email.
    `
  };
  tranport.sendMail(email);
}

export function sendResetPasswordEmail(user) {
  const tranport = setup();
  const email = {
    from:URI.EMAIL_USER_Name,
    to: user.email,
    subject: "Reset Password",
    html: `
    To reset password follow this 
    <a href=${user.generateResetPasswordLink()} >Link</a>
    `
  };
  tranport.sendMail(email);
}
