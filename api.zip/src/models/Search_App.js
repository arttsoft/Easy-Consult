const mongoose = require('mongoose');
const { text } = require('body-parser');
const Schema = mongoose.Schema;

const search_schema = new Schema({
  drname: {
    type:String,
    required:true
  },
  username: {
    type:String,
    required:true
  },
  email: {
    type:String,
    required:true
  },
  phone: {
    type:String,
    required:true
  },
  hospital:{
    type: String,
    required:true
  },
  lang: {
    type:String,
    required:true
  },  
  photo:{
    type: String,
    required:true
  },
  about:{
    type: String,
    required:true
  },
}, { timestamps: true });

search_schema.index({'$**': 'text'}, {weights:{
  drname:1, hospital:2
}});

const Doctors = mongoose.model('doctors', search_schema);

module.exports = { Doctors }