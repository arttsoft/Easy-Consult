const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const place_app_schema = new Schema({
    date: {
        type:String,
        required:true
        },
    time: {
        type:String,
        required:true
    },
    doc_id: {
        type:String,
        required:true
    },
    before_book: {
        type:String,
        required:true
    },
    create_room: {
        type:String,
        required:true
    },
    user_id: {
        type:String,
        required:true
    },
    type:{
        type: Boolean,
        required:true
    }
}, { timestamps: true });


const Place_App = mongoose.model('place_app', place_app_schema);

module.exports = Place_App; 