const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const lang_schema = new Schema({
  lang: {
    type: String,
    required:true
  },
  stats:{
    type: Number,
    required:true
  }
}, { timestamps: true });

const Language = mongoose.model('language', lang_schema);

module.exports = Language;