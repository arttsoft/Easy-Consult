const mongoose = require('mongoose');
const Schema = mongoose.Schema;


const hosp_schema = new Schema({
  hospital: {
    type:String,
    required:true
  },
  type:{
    type: Boolean,
    required:true
  }
}, { timestamps: true });


const Hospital = mongoose.model('hospital', hosp_schema);

module.exports = Hospital; 