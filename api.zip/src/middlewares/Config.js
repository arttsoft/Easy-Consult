
    module.exports.options = {
        // useMongoClient: true,
        useCreateIndex: true,
        useNewUrlParser: true,
        useUnifiedTopology: true,
        autoIndex: true, // Don't build indexes
        poolSize: 10, // Maintain up to 10 socket connections
        socketTimeoutMS: 30000, // Close sockets after 30 seconds of inactivity
        family: 4 // Use IPv4, skip trying IPv6
    };

    module.exports.JWT_SECRET = "50b78d201008693f0e09a4f80844d57e88ca81d2cc663adb9f4a88ed77c831e7"

    // module.exports.mongoURI = 'mongodb+srv://easyconsult:h8yODZK2JCNr3juH@easyconsult.0avxz.mongodb.net/easyconsult?authSource=admin&replicaSet=atlas-ghjln6-shard-0&w=majority&readPreference=primary&appname=MongoDB%20Compass%20Community&retryWrites=true&ssl=true';

    module.exports.mongoURI = 'mongodb://localhost:27017/easyconsult'

    module.exports.Port = '3537'


module.exports.HOST_dr = "https://dr.easyconsult.co.in"
module.exports.HOST = "https://care.easyconsult.co.in"


// module.exports.HOST_dr = "http://localhost:3000"
// module.exports.HOST = "http://localhost:3000"



module.exports.EMAIL_HOST="smtp.gmail.com"
module.exports.EMAIL_PORT="587"
module.exports.EMAIL_USER_Name="Easy Consult"
module.exports.EMAIL_USER="easyconsult20@gmail.com"
module.exports.EMAIL_PASS="ecAdmin@2020"

// module.exports.EMAIL_USER="karthickiaaxin@gmail.com"
// module.exports.EMAIL_PASS="iaaxin530544"

module.exports.EMAIL_SECURE=false
module.exports.EMAIL_AUTHO="plain"
module.exports.EMAIL_REJECT=false