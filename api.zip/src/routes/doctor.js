const express = require("express");
const Doctor = require("../models/Doctor");
const parseErrors = require("../utils/parseErrors");
// const sendConfirmationEmail = require("../mailer");
const authenticate = require("../middlewares/authenticate_dr");
const multer = require("multer");
// const mailer = require('../mailer');
const router = express.Router();

const storage = multer.diskStorage({
  destination: function (req, file, callback) {
    callback(null, "./src/dr_uploads");
  },
  filename: function (req, file, callback) {
    // console.log(file);
    callback(null, Date.now() + "-" + file.originalname);
  },
});
const upload = multer({ storage: storage }).single("myImage");

router.post("/", (req, res) => {
  // console.log(req.body.user, "----------------------------")
  const { drname, mcino, username, email, phone, password } = req.body.user;
  const user = new Doctor({ drname, mcino, username, email, phone });
  // console.log(drname, mcino, username, email, phone)
  user.setPassword(password);
  user.setConfirmationToken();
  user
    .save()
    .then(userRecord => {
      // console.log(userRecord);
      // mailer.sendConfirmationEmail(userRecord);
      console.log(userRecord.generateConfirmationUrl())
      res.json({ user: userRecord.toAuthJSON() });
    })
    // console.log({ errors: parseErrors(err.errors) })
    .catch(err => res.status(400).json({ errors: parseErrors(err.errors) }));
});

router.post("/upload", function (req, res, next) {
  // console.log('-------NEW TEST---------')
  upload(req, res, function (err) {
    if (err) {
      // console.log("Error Occured");
      return;
    }
    // console.log("---------------------", req.file.filename);  
    res.json({imgpath:req.file.filename})    
    // 
      
    //     
  });
});

router.get("/current_user", authenticate, (req, res) => {
  res.json({
    user: {
      email: req.currentUser.email,
      confirmed: req.currentUser.confirmed,
      username: req.currentUser.username
    }
  });
});

module.exports = router;
