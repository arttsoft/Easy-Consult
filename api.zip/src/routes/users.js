import express from "express";
import User from "../models/User";
import parseErrors from "../utils/parseErrors";
import { sendConfirmationEmail } from "../mailer";
import authenticate from "../middlewares/authenticate";
const multer = require("multer");

const router = express.Router();

const storage = multer.diskStorage({
  destination: function (req, file, callback) {
    callback(null, "./src/user_uploads");
  },
  filename: function (req, file, callback) {
    // console.log(file);
    callback(null, Date.now() + "-" + file.originalname);
  },
});
const upload = multer({ storage: storage }).single("myImage");

router.post("/", (req, res) => {
  // console.log(req.body.user)
  const { fullname, username, email, phone, password, photo, proof_f, proof_b } = req.body.user;
  const user = new User({ fullname, username, email, phone, photo, proof_f, proof_b });
  // console.log(fullname, username, email, phone, photo, proof_f, proof_b)
  user.setPassword(password);
  user.setConfirmationToken();
  user
    .save()
    .then(userRecord => {
      sendConfirmationEmail(userRecord);
      // console.log(userRecord.generateConfirmationUrl())
      res.json({ user: userRecord.toAuthJSON() });
    })
    .catch(err => res.status(400).json({ errors: parseErrors(err.errors) }));
});

router.post("/upload", function (req, res, next) {
  // console.log('-------NEW TEST---------')
  upload(req, res, function (err) {
    if (err) {
      // console.log("Error Occured");
      return;
    }
    // console.log("---------------------", req.file.filename);  
    res.json({imgpath:req.file.filename})    
    // 
      
    //     
  });
});

router.get("/current_user", authenticate, (req, res) => {
  res.json({
    user: {
      email: req.currentUser.email,
      confirmed: req.currentUser.confirmed,
      username: req.currentUser.username
    }
  });
});

export default router;
