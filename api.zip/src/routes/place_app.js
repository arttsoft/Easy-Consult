const express = require('express');
const router = express.Router();

// const Search = require('../models/Search_App');
const { Doctors } = require('../models/Search_App');


router.post("/doctor_search", (req, res) => {

  let order = req.body.order ? req.body.order : "desc";
  let sortBy = req.body.sortBy ? req.body.sortBy : "drname";
  let limit = req.body.limit ? parseInt(req.body.limit) : 100;
  let skip = parseInt(req.body.skip);
  // console.log(req.body.order)
  // console.log(req.body.sortBy)
  // console.log(req.body.limit)
  let findArgs = {};
  let term = req.body.searchTerm;
  // console.log(req.body.searchTerm)

  for (let key in req.body.filters) {
      // console.log(req.body.filters[key])
      if (req.body.filters[key].length > 0) {
        if (key === "lang") {
          findArgs[key] = {
              $regex: req.body.filters[key]
            }
        } else {
            findArgs[key] = req.body.filters[key];
        }
      }
  }

  if (term) {
    // console.log(term, "132545436457757878")
    // console.log(findArgs, "$$$$$$$$$$$$$$$$$$$$$$")
    // console.log(sortBy, order, skip, limit)
      Doctors.find(findArgs)
          // .find({ $text: { $search: term }})
          .find({ $or: [{"drname": { $regex: new RegExp(term), $options: 'si' }},{"hospital": { $regex: new RegExp(term), $options: 'si' }}] })
          .populate("_id")
          .sort([[sortBy, order]])
          .skip(skip)
          .limit(limit)
          .exec((err, doctor) => {
              // console.log(doctor, err)
              if (err) return res.status(400).json({ success: false, err })
              res.status(200).json({ success: true, doctor, postSize: doctor.length })
          })
  } else {
      // console.log(findArgs, "######################")
      Doctors.find(findArgs)
          .populate("_id")
          .sort([[sortBy, order]])
          .skip(skip)
          .limit(limit)
          .exec((err, doctor) => {
              if (err) return res.status(400).json({ success: false, err })
              res.status(200).json({ success: true, doctor, postSize: doctor.length })
          })
  }

});


router.get("/doctor_id", (req, res) => {
  let type = req.query.type
  let doctorsId = req.query.id

  console.log("req.query.id", req.query.id)

  if (type === "array") {
      let ids = req.query.id.split(',');
      doctorsId = [];
      doctorsId = ids.map(item => {
          return item
      })
  }

  console.log("doctorsId", doctorsId)

  //we need to find the product information that belong to product Id 
  Doctors.find({ '_id': { $in: doctorsId } })
      .populate('writer')
      .exec((err, doctor) => {
          if (err) return res.status(400).send(err)
          return res.status(200).send(doctor)
      })
});

module.exports = router;


