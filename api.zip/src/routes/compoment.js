const express = require('express');
const router = express.Router();

const Language  = require('../models/language');
const Hospital = require('../models/hospital');
// const { isMatch } = require('lodash');
// router.post('/doctor_search', (req, res) => {
//   // console.log('----- REQ.BODY -----',req.body);
//   const drname = req.body.drname;
//   const hlname = req.body.hlname;
//   Search.find({$and:[{"drname": { $regex: '.*' + drname + '.*' }},{"hlname": { $regex: '.*' + hlname + '.*' }}]})
//   .then(result=>{
//     if(result){
//       res.json({result})
//     } else {
//       res.json({'msg':'Not Found'})
//     }
//   })
// })

router.post('/language', (req, res) => {
    Language.find()
        .populate("_id")
        .sort("lang")
        .exec((err, language) => {
            if(err) return res.status(400).json({success: false, err})
            // console.log(language)
            res.status(200).json({success: true, language})
        })
        
})

router.post('/hospital', (req, res) => {
    Hospital.find()
        .populate("_id")
        .sort("hospital")
        .exec((err, hospital) => {
            if(err) return res.status(400).json({success: false, err})
            // console.log(Hospital)
            res.status(200).json({success: true, hospital})
        })
        
})

module.exports = router