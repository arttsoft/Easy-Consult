const express = require("express");
const path = require("path") 
const mongoose = require("mongoose") ;
const bodyParser = require("body-parser") ;
const cors = require("cors") ;
const URI = require("./middlewares/Config") ;
const Promise = require("bluebird") ;
const http = require("http") ;
const socket = require('socket.io') ;

const auth = require("./routes/auth") ;
const auth_dr = require("./routes/auth_dr") ;
const users = require("./routes/users") ;
const doctor = require("./routes/doctor") ;
const search = require("./routes/search") ;
const place_app = require("./routes/place_app") ;
const compo = require("./routes/compoment") ;
// import video_server from './routes/video_server'


const app = express();
app.use(bodyParser.json());
mongoose.Promise = Promise;
// mongoose.Promise= global.Promise;

app.use(cors())
// app.use(cors())

app.use(bodyParser.urlencoded({ extended: true }));
// app.use(bodyParser.json());

mongoose.connect(URI.mongoURI, URI.options)
  .then(() => console.log('Server Connected...'))
  .catch(err => console.log(err));

app.use("/dr_uploads", express.static(path.join(__dirname, "dr_uploads")));
app.use("/user_uploads", express.static(path.join(__dirname, "user_uploads")));

app.use("/api/auth", auth);
app.use("/api/auth_dr", auth_dr);
app.use("/api/users", users);
app.use("/api/doctor", doctor);
app.use("/api/search", search);
app.use("/api/place_app", place_app);
app.use("/api/compoment", compo);
// app.use('/api/video_server', video_server)

app.get("/*", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

const server = http.createServer(app);
const io = socket(server);

var consult_user = {};

var socketToRoom = {};

io.on('connection', socket => {
    socket.on("join room", roomID => {
        if (consult_user[roomID]) {
            // console.log(consult_user[roomID])
            const length = consult_user[roomID].length;
            if (length === 4) {
                socket.emit("room full");
                return;
            }
            // console.log(consult_user[roomID])
            consult_user[roomID].push(socket.id);
        } else {
            consult_user[roomID] = [socket.id];
        }
        socketToRoom[socket.id] = roomID;
        const usersInThisRoom = consult_user[roomID].filter(id => id !== socket.id);

        socket.emit("all consult_user", usersInThisRoom);
    });

    socket.on("sending signal", payload => {
        io.to(payload.userToSignal).emit('user joined', { signal: payload.signal, callerID: payload.callerID });
    });

    socket.on("returning signal", payload => {
        io.to(payload.callerID).emit('receiving returned signal', { signal: payload.signal, id: socket.id });
    });

    socket.on('disconnect', () => {
      const roomID = socketToRoom[socket.id];
      let room = consult_user[roomID];
      if (room) {
          room = room.filter(id => id !== socket.id);
          consult_user[roomID] = room;
      }
  });

});

// app.listen(URI.Port);
server.listen(URI.Port);
