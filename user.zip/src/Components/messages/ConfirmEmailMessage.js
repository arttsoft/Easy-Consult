import React from "react";

const ConfirmEmailMessage = () => (
  <div className="alert alert-warning">
    Please, verify your email to unlock awesomeness
  </div>
);

export default ConfirmEmailMessage;
