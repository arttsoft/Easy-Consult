import React, { Component } from 'react';
import Consult_Form from '../Forms/Consult_Form';

class Consult_Page extends Component {

  render() {
   // console.log('***********',this.state.mydata); col-sm-4  DoctorID={this.props.location.DoctorID}
    return (
        <div className="row container-fluid">
          <div className="container-fluid col-sm-8">
              <h2 className="card-header text-center" style={{backgroundColor: "red", color: "white"}} >Consulting</h2>
              <div className="card-body" style={{backgroundColor:'#fceded', height:'39rem', overflowY: 'scroll'}}>
                <Consult_Form />
              </div>
          </div>
      </div>
    );
  }
}

export default Consult_Page;