import React from "react";
import SignupForm from "../Forms/SignupForm";

const SignupPage = () => (
  <div className="clientform">
    <div className="container" style={{ height: "85vh" }}>
      <div className="row align-items-center" style={{ height: "85vh" }}>
        <div className="col-xs-6 col-sm-12 col-lg-6 offset-lg-3 offset-xs-6">
          <div className="card cardbodyMager">
            {/* <h2 className="card-header" style={{backgroundColor: "red", color: "white"} >Welcome Back!</h2> */}
            <h2 className="card-header text-center" 
                style={{backgroundColor: "red", color: "white"}} >
                  <b>Register</b></h2>
            <div className="card-body">
              <SignupForm />
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
);

export default SignupPage;
