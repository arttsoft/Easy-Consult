import React from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import ConfirmEmailMessage from "../messages/ConfirmEmailMessage";
// import Sidebar_Red from "../Forms/Sidebar_Red";
// import SideBar_Blue from "../Forms/SideBar_Blue";

class DashboardPage extends React.Component {
  render() {
    const { isConfirmed } = this.props;

    // this.props.history.push(`/con_room/${DoctorID}`);

    return (
      <div className="App">
        {!isConfirmed && <ConfirmEmailMessage />}
          {/* <div className="row container-fluid"> */}
              {/* <div className="col-md-4" >                        */}
                  {/* <div style={{backgroundColor:'#fceded',height: '100%',overflowY: 'scroll'}}> */}
                      {/* <Sidebar_Red /> */}
                      <h1>Welcome to Easyconsult</h1>
                  {/* </div> */}
              {/* </div> */}
              {/* <div className="col-md-8" style={{backgroundColor:'#edf8ff',height:'92vh',overflowY: 'scroll'}}>
                  <SideBar_Blue />
              </div> */}
          {/* </div> */}
      </div>
    );
  }
}

DashboardPage.propTypes = {
  isConfirmed: PropTypes.bool.isRequired
};

function mapStateToProps(state) {
  return {
    isConfirmed: !!state.user.confirmed
  };
}

export default connect(mapStateToProps)(DashboardPage);
