import React from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { Link } from "react-router-dom";
import validator from 'validator';
import { createUserRequest } from "../../actions/users";
import Image_Upload from "../../others/Image_Upload";
// import { Upload } from 'antd';
import axios from 'axios';
import { apiUrl } from "../../others/config";


class SignupForm extends React.Component {
  state = {
    data: {
      fullname: "",
      username: "",
      email: "",
      phone: "",
      password: "",
      password2: '',
      photo: '',
      proof_f: '',
      proof_b: '',
      checkterm: ''
    },
    errors: {}
  };

  componentWillReceiveProps(nextProps) {
    this.setState({ errors: nextProps.serverErrors });
  }

  onChange = e =>
    this.setState({
      data: { ...this.state.data, [e.target.name]: e.target.value }
    });
  
  onChangeNo = e => {
      const re = /^[0-9\b]+$/;
      if (e.target.value === '' || re.test(e.target.value))  {
        if (e.target.value.length !== 11) {
          this.setState({ data: {...this.state.data, [e.target.name]: e.target.value}})
        }
      }
   };

  onSubmit = e => {
    e.preventDefault();
    const errors = this.validate(this.state.data);
    this.setState({ errors });
    if (Object.keys(errors).length === 0) {
      this.setState({ loading: true });
      this.props.submit(this.state.data);
    }
  };

  onChecked = e => {
    if(this.state.Checked){
      this.submit.disable=true
    }else {
      this.submit.disable=false
    }
  }

  validate = data => {
    const errors = {};
    
    if (!data.fullname) {
      errors.fullname="Name Can't Empty"
    }      
    if (data.password !== data.password2) {
      errors.password = "Password Mismatch"
    }
    if (!data.username) {
      errors.username = "UserName Can't Empty"
    }
    if(data.phone.length !== 10) errors.phone = "Invalid Phone"
    // if (!validator.isMobilePhone(data.phone)){
    //   errors.uname="Invalid Phone"
    // }
    if(!validator.isEmail(data.email)){
      errors.email = "Invalid E-mail"
    }
    if (!data.password) {
      errors.password = "Invalid Password"
    }
    if (data.password.length <= 6) {
      errors.password = "Password min Lenth 6"
    }
    // if(data.photo === '' || data.photo === undefined ){
    //   errors.photo = "Invalid Image"
    //   data.photo="."
    // }
    //  if(data.proof_f === '' || data.proof_f === undefined ){
    //   errors.proof_f = "Invalid Image"
    //   data.photo="."
    //  }
    //  if(data.proof_b === '' || data.proof_b === undefined ){
    //   errors.proof_b = "Invalid Image"
    //  }

     if(data.checkterm) errors.checkterm = "Please Accept terms or exit"

    return errors;
  };

  file_photo = (e)=>{                   
    const formData = new FormData();  
    formData.append("myImage", e);
    const config = {
      headers: {
        "content-type": "multipart/form-data"
      }
    };
    // console.log('-- RESPONSE --', formData)
    axios.post(`${apiUrl}/api/users/upload`,formData,config)
    .then(response =>{
        // console.log('-- RESPONSE --', response.data.imgpath)             
        this.setState( { data: {...this.state.data, photo: response.data.imgpath} })    
    })
    .catch(err =>{
        console.log('-- err --',err)
    })        
    //this.setState( { data: {...this.state.data, photo: e} })        
  }
  file_proof_f = (e)=>{ 
    const formData = new FormData();  
    formData.append("myImage", e);
    const config = {
      headers: {
        "content-type": "multipart/form-data"
      }
    };
    axios.post(`${apiUrl}/api/users/upload`,formData,config)
    .then(response =>{
        // console.log('-- RESPONSE --', response.data.imgpath)             
        this.setState( { data: {...this.state.data, proof_f: response.data.imgpath} })    
    })
    .catch(err =>{
        console.log('-- err --',err)
    })  
    //this.setState( { data: {...this.state.data, proof_f: e} }) 
  }
  
  file_proof_b = (e)=>{  
    const formData = new FormData();  
    formData.append("myImage", e);
    const config = {
      headers: {
        "content-type": "multipart/form-data"
      }
    };
    axios.post(`${apiUrl}/api/users/upload`,formData,config)
    .then(response =>{
        // console.log('-- RESPONSE --', response.data.imgpath)             
        this.setState( { data: {...this.state.data, proof_b: response.data.imgpath} })    
    })
    .catch(err =>{
        console.log('-- err --',err)
    }) 
   // this.setState( { data: {...this.state.data, proof_b: e} }) 
  }

  render() {
    const { data, errors } = this.state;

    return (
      <form onSubmit={this.onSubmit}>
        <div className="row">
          <div className="col-7">
            <div className="form-group">
              <label className="formlabel" htmlFor="fullname">Full Name</label>
              <input
                type="fullname"
                id="fullname"
                name="fullname"
                value={data.fullname}
                onChange={this.onChange}
                required
                className={
                  errors.fullname ? "form-control is-invalid" : "form-control"
                }
              />
              <div className="invalid-feedback">{errors.fullname}</div>
            </div>

            <div className="form-group">  
              <label className="formlabel" htmlFor="email">Email</label>&nbsp;&nbsp;
              {/* <input type="checkbox" id="checkuser" name="checkuser" value={data.checkuser} onChange={this.onCheck} /> */}
              <input
                type="email"
                id="email"
                name="email"
                required
                value={data.email}
                onChange={this.onChange}
                className={
                  errors.email ? "form-control is-invalid" : "form-control"
                }
              />
              <div className="invalid-feedback">{errors.email}</div>
            </div>

            <div className="form-group">  
              <label className="formlabel" htmlFor="phone">Phone Number</label>
              <input
                type="phone"
                id="phone"
                name="phone"
                required
                value={data.phone}
                onChange={this.onChangeNo}
                className={
                  errors.phone ? "form-control is-invalid" : "form-control"
                }
              />
              <div className="invalid-feedback">{errors.phone}</div>
            </div>

            <div className="form-group">
              <label className="formlabel" htmlFor="username">Username</label>
              <input
                type="text"
                id="username"
                name="username"
                required
                value={data.username}
                onChange={this.onChange}
                className={
                  errors.username ? "form-control is-invalid" : "form-control"
                }
              />
              <div className="invalid-feedback">{errors.username}</div>
            </div>

            <div className="form-group">
              <label className="formlabel" htmlFor="password">Password</label>
              <input
                type="password"
                id="password"
                name="password"
                required
                value={data.password}
                onChange={this.onChange}
                className={
                  errors.password ? "form-control is-invalid" : "form-control"
                }
              />
              <div className="invalid-feedback">{errors.password}</div>
            </div>

            <div className="form-group">
              <label className="formlabel" htmlFor="password2">Confirm Password</label>
              <input
                type="password"
                id="password2"
                name="password2"
                required
                value={data.password2}
                onChange={this.onChange}
                className={
                  errors.password2 ? "form-control is-invalid" : "form-control"
                }
              />
              <div className="invalid-feedback">{errors.password2}</div>
            </div>
          </div>
          <div className="col-5">
              <div className="form-group">
                  <label style={{fontWeight:700}}>Upload Your Photo</label>
                  <Image_Upload onFileChange={this.file_photo} value={data.file_photo}
                  />
                  <div className="invalid-feedback">{errors.file_photo}</div>
              </div>

              <div className="form-group">
                    <label style={{fontWeight:700}}>Upload ID Proof Front (with Photo and Address)</label>
                    <Image_Upload onFileChange={this.file_proof_f} value={data.proof_f} />      
                    <div className="invalid-feedback">{errors.file_photo_f}</div>
                </div>

              <div className="form-group">
                <label style={{fontWeight:700}}>Upload ID Proof Back</label>
                  <Image_Upload onFileChange={this.file_proof_b} value={data.file_proof_b} /> 
                  <div className="invalid-feedback">{errors.file_photo_b}</div>
                </div>
          </div>
        </div>
        
        
        <div className="form-group h5 text-center">
              <input 
              type="checkbox" 
              id="checkterm" 
              name="checkterm" 
              value={data.checkterm} 
              required
              label="" />&nbsp;&nbsp;
              <label for="checkterm">I agree to your all <Link to="/#">privacy, terms & conditions</Link>.</label>            
            <div className="invalid-feedback">{errors.checkterm}</div>
        </div>

        <button type="submit" className="btn btn-primary btn-block cardbutton">
          Submit
        </button>
            <br />
        <small className="form-text text-center h5">
          or <Link to="/login">Login</Link> if you have an account
        </small>
      </form>
    );
  }
}

function mapStateToProps(state) {
  return {
    serverErrors: state.formErrors.signup
  };
}

SignupForm.propTypes = {
  submit: PropTypes.func.isRequired
};

export default connect(mapStateToProps, { submit: createUserRequest })(
  SignupForm
);
