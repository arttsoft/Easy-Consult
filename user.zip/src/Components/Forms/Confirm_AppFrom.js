import React, { useEffect, useState } from 'react'
import Axios from 'axios'
import App_Table from '../tools/App_Table';
import moment from 'moment'
import { DatePicker } from 'antd';
// import { useDispatch } from 'react-redux';
import { apiUrl } from '../../others/config';
import "../../others/style.css";
// import queryString from 'query-string';


function Confirm_AppFrom(props) {
    const [Doctor, setDoctor] = useState([])
    const [Doctors, setDoctors] = useState([])
    const [booked, setBooked] = useState(true)
    const [Date, setDate] = useState("")
    
    useEffect(() => {
        const data = {
            id: (props.DoctorID), type: true
        }
        // console.log('---- data ----',data);
        Axios.post(`${apiUrl}/api/search/doctor_id`, data)
        .then(response => {
            console.log('-----response----',response);
            if (response.data.success) {
                setDoctors(response.data.doctor[0])
                // console.log(response.data.doctor)
            } else {
                alert('Failed to fectch Doctors datas')
            }
        })
    }, [])


    useEffect(() => {
        // const data = {
        //     date: Date
        // }
        // console.log('---- data ----',data);
        // Axios.post(`${apiUrl}/api/search/doctor_id`, data)
        // .then(response => {
        //     console.log('-----response----',response);
        //     if (response.data.success) {
        //         setDoctors(response.data.doctor)
        //         // console.log(response.data.doctor)
        //     } else {
        //         alert('Failed to fectch Doctors datas')
        //     }
        // })
    }, [])

    function BuildAppTable() {

        // const data1 = [];
        // try {
        //     var D1=moment(Date1, "YYYY-MM-DD")
        //     // console.log(AddDays)
        //     var key1 = 1;
            
        //             data1.push({
        //                 key: key1,
        //                 time: (moment(AddTime).format('h:mm A')),
        //             })
        //             key1++;
        // } catch (error) {
        //     alert("Something wrong", error)
        //     setDisable(true);
        // }
        // setdata(data1)
    }

    function handelChange(date, dateStrings) {
        try {
            setDate(moment(dateStrings, "YYYY-MM-DD"))
        } catch (error) {
            alert("Select Date")
        }
    }

    function disabledDate(current) {
        return current && current < moment().endOf('day');
    }

    return (
        <div>
            <div className="row cardbody box1" > {/* onClick={()=>{submit(doctor._id)}} */ }
                <div style={{borderRight: '0.5px solid'}}>  
                    <img src={`${apiUrl}/dr_uploads/${Doctors.photo}`} className="cardover"/>
                </div> 
                <div style={{marginLeft: '1rem'}}>
                    <h4><b>Dr.{Doctors.drname}{Doctors.quali}</b></h4>
                    <h6 ><p className="line-height">{Doctors.spec}</p>
                    <p className="line-height"><b>Reg. No.</b> {Doctors.regno},      <b>Know Language:</b> {Doctors.lang}</p>
                    <p className="line-height"><b>Phone:</b> {Doctors.phone2} <b>E-Mail:</b> {Doctors.email}</p>
                    <p className="line-height"><b>About me:</b> {Doctors.about}</p></h6>
                </div>
            </div>

            <div className="row">
                <div className="col-md-12">
                    <div className="row" style={{marginTop:'3rem'}}>
                        <div className="col-md-5" style={{backgroundColor:'#fff'}}>
                        <div className="row" >
                                <div className="col-md-6" style={{padding:'1rem'}}>
                                    <h5>Appointment Date</h5>
                                </div>
                                <div className="col-md-6" style={{padding:'1rem'}}>
                                    <DatePicker size="large" disabledDate={disabledDate} onChange={handelChange} style={{width: '100%'}} />
                                </div>
                            </div>
                            <div className="row">
                                <App_Table />
                            </div>
                        </div>

                        {booked ? 
                        <div className="col-md-6 " style={{borderLeft: '0.5px'}}>
                        <div className="card text-white bg-primary mb-3" style={{maxWidth: '38rem'}}>
                            <div className="card-header center-text" style={{fontWeight:'bold',fontSize:'1.5rem'}}>Booking</div>
                            <div className="card-body" style={{backgroundColor:'#fff',color:'#000'}}>
                            <table className="table">
                                <thead>
                                    <tr>                                
                                        <td scope="col">Date</td>
                                        <td scope="col" style={{color:'#eb4d4b'}}>02-06-2020</td>                              
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>                                      
                                        <td style={{fontWeight:'bold'}}>Time</td>
                                        <td style={{color:'#eb4d4b'}}>10 Am - 11 Am</td>                                                       
                                    </tr>
                                    <tr>                                      
                                        <td style={{fontWeight:'bold'}}>Consulting Fees: </td>
                                        <td style={{color:'#000',fontWeight:'bold'}}>Rs 250</td>                                                       
                                    </tr>                                                           
                                </tbody>
                                </table>
                                <h6>After Payment Confirm, Booking your Appointment is Completed</h6>
    
                                <div className="row">
                                    <div className="col-md-6">
                                        <button className="btn btn-success" style={{width:'7rem',marginTop:'1.5rem'}}>Pay</button>
                                    </div>
                                    <div className="col-md-6">
                                    <button className="btn btn-danger" 
                                        style={{width:'7rem',marginTop:'1.5rem'}}
                                        onClick= "/doctorapp" > Cancel</button>
                                    </div>      
                                </div>
                           
                            </div>
                        </div>
                        </div>
                        : null}
                    </div>  
                </div>
            </div>

            
            {/* <div style={{ display: 'flex', justifyContent: 'center' }}>
                <h1>{DoctorID}</h1>
            </div>
            <br />

            <Row gutter={[16, 16]} >
                <Col lg={12} xs={24}>
                    {/* <DoctorImage detail={Doctor} /> 
                </Col>
                <Col lg={12} xs={24}>
                    {/* <DoctorInfo
                        addToCart={addToCartHandler}
                        detail={Doctor} />
                </Col>
            </Row> */}
        </div>
    )
}


export default Confirm_AppFrom;