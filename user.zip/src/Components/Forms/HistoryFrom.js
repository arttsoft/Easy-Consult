import React from 'react'

export default function HistoryFrom() {
    return (
        <div>
            HistoryFrom
        </div>
    )
}
