import React from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'


function SideBar_Blue() {
    return (
        <div>
            "Blue"
        </div>
    )
}

SideBar_Blue.propTypes = {
    isConfirmed: PropTypes.bool.isRequired
  };
  
  function mapStateToProps(state) {
    return {
      isConfirmed: !!state.user.confirmed
    };
  }
  
  export default connect(mapStateToProps)(SideBar_Blue);