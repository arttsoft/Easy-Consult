import React, { Component } from 'react'
import { Navbar, Nav } from "react-bootstrap"
import Logo from "../../Image/Logo.png"

export default class GuestNav extends Component {
    render() {
        return (
            <Navbar collapseOnSelect expand="lg" className="navcolor">
                <Navbar.Brand href="/">
                <img className="navlogo d-inline-block align-top" src={Logo}  
                alt="React Bootstrap logo" />
                    </Navbar.Brand>
                <Navbar.Toggle aria-controls="responsive-navbar-nav" />
                <Navbar.Collapse id="responsive-navbar-nav">
                    <Nav className="mr-auto" />
                    <Nav className="h5">
                        <Nav.Link style={{color: "white"}} href="/login">Login</Nav.Link>
                        <Nav.Link style={{color: "white"}} href="/register">Register</Nav.Link>
                    </Nav>
                </Navbar.Collapse>
            </Navbar>
        )
    }
}
