import {
  CREATE_USER_REQUEST,
  CREATE_USER_FAILURE,
  FETCH_CURRENT_USER_REQUEST,
  FETCH_CURRENT_USER_SUCCESS,
  FETCH_CURRENT_DOCTOR_REQUEST,
  FETCH_CURRENT_DOCTOR_SUCCESS
} from "../others/types";

export const createUserRequest = user => ({
  type: CREATE_USER_REQUEST,
  user
});

export const createUserFailure = errors => ({
  type: CREATE_USER_FAILURE,
  errors
});

export const fetchCurrentUserRequest = () => ({
  type: FETCH_CURRENT_USER_REQUEST
});

export const fetchCurrentUserSuccess = user => ({
  type: FETCH_CURRENT_USER_SUCCESS,
  user
});

export const fetchCurrentDoctorRequest = user => ({
  type: FETCH_CURRENT_DOCTOR_REQUEST,
  user
})

export const fetchCurrentDoctorSuccess = user => ({
  type: FETCH_CURRENT_DOCTOR_SUCCESS,
  user
})
