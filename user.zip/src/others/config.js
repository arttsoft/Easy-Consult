const production = false;

export const apiUrl = production
  ? "http://31.220.59.205:3535"
  : "http://localhost:3535";
