export default {
  en: {
    "nav.dashboard": "Dashboard"
  },
  ru: {
    "nav.dashboard": "Панель Управления"
  }
};
