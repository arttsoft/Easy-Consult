import React, { Component } from 'react';
//import ReactDOM from "react-dom";
//import User_Register from '../Pages/User_Register';
//<input type="file" onChange={this.onChange} />


export default class Image_Upload extends Component {
  constructor(props) {
    super(props);
    this.state = { file: null,file1:'' };
    this.onChange = this.onChange.bind(this);
    this.resetFile = this.resetFile.bind(this);
  }

  onChange(event) {
    this.setState({
      file: URL.createObjectURL(event.target.files[0]),file1: event.target.files[0]
    },()=>{this.props.onFileChange(this.state.file1)});
  }

  resetFile(event) {
    event.preventDefault();
    this.setState({ file: null });
  }
  
  render() {
    return (
      <div>
          {!this.state.file && (
           <input type="file" onChange={this.onChange} />
            )}
            
          {this.state.file && (
            <div style={{ textAlign: "center" }}>
                <img className="img-border" src={this.state.file} alt="new" width="100" height="100"/>
               
                <div>
                  <button className="btn btn-danger" onClick={this.resetFile}>Remove</button>
                </div>
            </div>
            )}
      </div>
    );
  }
}