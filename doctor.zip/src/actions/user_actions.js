import axios from 'axios';
import {
    FETCH_CURRENT_DOCTOR_REQUEST,
    FETCH_CURRENT_DOCTOR_SUCCESS
} from './types';
import { apiUrl } from '../others/config';


export function addToDoctor(_id) {
    const request = axios.get(`${apiUrl}/addToCart?productId=${_id}`)
        .then(response => response.data);

    return {
        type: FETCH_CURRENT_DOCTOR_REQUEST,
        payload: request
    }
}