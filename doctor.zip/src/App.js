import React from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { Route } from "react-router-dom";

import GuestRoute from "./routes/GuestRoute";
import UserRoute from "./routes/UserRoute";
import Loader from "react-loader";
// import Loader from "react-loader-spinner";
import { IntlProvider } from "react-intl";
import LoginPage from "./Components/Pages/LoginPage";
import DashboardPage from "./Components/Pages/DashboardPage";
import SignupPage from "./Components/Pages/SignupPage";
import ConfirmationPage from "./Components/Pages/ConfirmationPage";
import ForgotPasswordPage from "./Components/Pages/ForgotPasswordPage";
import ResetPasswordPage from "./Components/Pages/ResetPasswordPage";
import ProfilePage from "./Components/Pages/ProfilePage";

import GuestNav from "./Components/Navbar/GuestNav";
import TopNavigation from "./Components/Navbar/TopNavigation";
// import Consult_Page from "./Components/Pages/Consult_Page";ProfilePage
// import Search_AppPage from "./Components/Pages/Search_AppPage"
// import Video_Page from "./Components/Pages/Video_Chart"
import { fetchCurrentUserRequest } from "./actions/users";
// import Confirm_AppPage from './Components/Pages/Confirm_AppPage'
import messages from "./others/messages";

class App extends React.Component {
  componentDidMount() {
    if (this.props.isAuthenticated) this.props.fetchCurrentUserRequest();
  }

  render() {
    const { location, isAuthenticated, loaded, lang } = this.props;

    return (
      <IntlProvider locale={lang} messages={messages[lang]}>
        <div>
          <Loader loaded={loaded} messages={messages[lang]}>   {/*classname="App" type="BallTriangle" color="#00BFFF"*/}

            {isAuthenticated
            ? <TopNavigation />
            : <GuestNav />}
            
            {isAuthenticated
            ? <UserRoute location={location} path="/" exact component={DashboardPage} />
            : <Route location={location} path="/" exact component={LoginPage} />}

            <GuestRoute
              location={location}
              path="/confirmation/:token"
              exact component={ConfirmationPage}
            />
            <GuestRoute
              location={location}
              path="/login"
              exact
              component={LoginPage}
            />
            <GuestRoute
              location={location}
              path="/register"
              exact
              component={SignupPage}
            />
            <GuestRoute
              location={location}
              path="/forgot_password"
              exact
              component={ForgotPasswordPage}
            />
            <UserRoute
              location={location}
              path="/reset_password/:token"
              exact
              component={ResetPasswordPage}
            />
            <UserRoute
              location={location}
              path="/dashboard"
              exact
              component={DashboardPage}
            />
            <UserRoute
              location={location}
              path="/profile"
              exact
              component={ProfilePage}
            />
            {/* <UserRoute
              location={location}
              path="/consult"
              exact
              component={Consult_Page}
            /> */}
            {/* <UserRoute
              location={location}
              path="/con_app/:roomID"
              exact
              component={Video_Page}
            /> */}
            {/* <UserRoute
              location={location}
              path="/app_book"
              exact
              component={Search_AppPage}
            /> */}
            {/* <UserRoute
              location={location}
              path="/doctorapp"
              exact
              component={Confirm_AppPage}
            /> */}
          </Loader>
        </div>
      </IntlProvider>
    );
  }
}

App.propTypes = {
  location: PropTypes.shape({
    pathname: PropTypes.string.isRequired
  }).isRequired,
  isAuthenticated: PropTypes.bool.isRequired,
  fetchCurrentUserRequest: PropTypes.func.isRequired,
  loaded: PropTypes.bool.isRequired,
  lang: PropTypes.string.isRequired
};

function mapStateToProps(state) {
  return {
    isAuthenticated: !!state.user.email,
    loaded: state.user.loaded,
    lang: state.locale.lang
  };
}

export default connect(mapStateToProps, { fetchCurrentUserRequest })(App);
