const production = true;

export const apiUrl = production
  ? "http://122.165.160.174:3537"
  : "http://localhost:3537";
