import React from 'react';
import { Tabs } from 'antd';
import PersonalDet from './Profile/PersonalDet';
import Qulification from './Profile/Qulification';
import PrimaryDetails from './Profile/PrimaryDetails';
import AccountDet from './Profile/AccountDet';

const { TabPane } = Tabs;

function callback(key) {
  console.log(key);
}

const ProfileForm = () => (
  <Tabs defaultActiveKey="1" onChange={callback}>
    <TabPane tab="Personal Details" key="1">
      <PersonalDet />
    </TabPane>
    <TabPane tab="Qualification" key="2">
      <Qulification />
    </TabPane>
    <TabPane tab="Primary Details" key="3">
      <PrimaryDetails />
    </TabPane>
    <TabPane tab="Account Details" key="4">
      <AccountDet />
    </TabPane>
  </Tabs>
);

export default ProfileForm