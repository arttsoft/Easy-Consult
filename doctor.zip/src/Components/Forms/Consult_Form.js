import React, { useEffect, useState } from 'react'
import Axios from 'axios'
import { apiUrl } from '../../others/config';


function Consult_Form(props) {

    const [Doctors, setDoctors] = useState([]);
    const DoctorID = "5ef454688015240e74ef23a6";

    useEffect(() => {
        const data = {
                id: (DoctorID), type: true
            }
            // console.log('---- data ----',data);
            Axios.post(`${apiUrl}/api/search/doctor_id`, data)
            .then(response => {
                console.log('-----response----',response);
                if (response.data.success) {
                    setDoctors(response.data.doctor[0])
                    // console.log(response.data.doctor)
                } else {
                    alert('Failed to fectch Doctors datas')
                }
            })
        }, [])

    return (
        <div>
            <div className="row cardbody box1" onClick={event =>  window.location.href=`/con_app/${DoctorID}`}> {/* onClick={()=>{submit(doctor._id)}} */ }
                <div style={{borderRight: '0.5px solid'}}>  
                    <img src={`${apiUrl}/dr_uploads/${Doctors.photo}`} className="cardover"/>
                </div> 
                <div style={{marginLeft: '1rem'}}>
                    <h4><b>Dr.{Doctors.drname}{Doctors.quali}</b></h4>
                    <h6 ><p className="line-height">{Doctors.spec}</p>
                    <p className="line-height"><b>Reg. No.</b> {Doctors.regno},      <b>Know Language:</b> {Doctors.lang}</p>
                    <p className="line-height"><b>Phone:</b> {Doctors.phone2} <b>E-Mail:</b> {Doctors.email}</p>
                    <p className="line-height"><b>About me:</b> {Doctors.about}</p></h6>
                </div>
            </div>
        </div>
    )
}

export default  Consult_Form;