import React , { useEffect, useState } from 'react';
import Axios from 'axios';
import 'antd/dist/antd.css';
import { Col, Row  } from 'antd';
import CheckBox from '../tools/CheckBox';
import RadioBox from '../tools/RadioBox';

// import { lang, hlname } from '../tools/Datas';
import SearchFeature from '../tools/SearchFeature';
import { apiUrl } from '../../others/config';
import "../../others/style.css";
import { Button } from 'reactstrap';
import { withRouter } from 'react-router-dom';


function Search_AppFrom(props) {
    const [Doctors, setDoctors] = useState([])
    const [Skip, setSkip] = useState(0)
    const [Limit, setLimit] = useState(10)
    const [PostSize, setPostSize] = useState()
    const [SearchTerms, setSearchTerms] = useState("")
    const [Hospital, setHospital] = useState([])
    const [Language, setLanguage] = useState([])

    const [Filters, setFilters] = useState({
        Hospital: [],
        Language: []
    })

    useEffect(() => {
        getLanguage();
        getHospital();
        const variables = {
            skip: Skip,
            limit: Limit,
        }
        getDoctors(variables)
    }, [])

    

    const submit = (doctorid) => {

        props.history.push({pathname: '/doctorapp', DoctorID: doctorid})
        // props.push({pathname:"/doctorapp", data: doctorid})
    }
    //props.history.push(`/doctorapp/:${doctorid}`)
    // const submit = (doctorid) => {
    //     console.log(doctorid, "sdfsdfdsfsfsdfsfsfd")
    //     props.history.push({pathname: '/doctorapp', DoctorID: doctorid})}
    // const submit = (doctorid) => props.history.push({'/doctorapp', doctorid});

    const getDoctors = (variables) => {
        Axios.post(`${apiUrl}/api/search/doctor_search`, variables)
            .then(response => {
                if (response.data.success) {
                    if (variables.loadMore) {
                        setDoctors(response.data.doctor)
                    } else {
                        setDoctors(response.data.doctor)
                    }
                    setPostSize(response.data.postSize)
                    // console.log(response.data.postSize, ">=", Limit)
                } else {
                    alert('Failed to fectch Doctors datas')
                }
            })
    }

    const getLanguage = () => {
        Axios.post(`${apiUrl}/api/compoment/language`)
            .then(response => {
                if (response.data.success) {
                    setLanguage(response.data.language)
                    setPostSize(response.data.postSize)
                } else {
                    alert('Yet datas')
                }
            })
    }

    const getHospital = () => {
        Axios.post(`${apiUrl}/api/compoment/hospital`)
            .then(response => {
                if (response.data.success) {
                    setHospital(response.data.hospital)
                    setPostSize(response.data.postSize)
                } else {
                    alert('Yet datas')
                }
            })
    }

    const onLoadMore = () => {
        let skip = Skip + Limit;

        const variables = {
            skip: skip,
            limit: Limit,
            loadMore: true,
            filters: Filters,
            searchTerm: SearchTerms
        }
        getDoctors(variables)
        setSkip(skip)
    }

    // const onMessage = (doctorid, doctorname) => {
    //     var option = window.confirm(`Are You Select ${doctorname} `);
    //     if (option) {
    //        submit(doctorid)
    //        };
    //     }
    //cover={<a href={`/doctor/${doctor._id}`}> </a>} 
    const renderCards = Doctors.map((doctor, index) => {
        return <Col lg={24} md={32} xs={24}>
            <div className="row cardbody box"
                onClick={()=>{submit(doctor._id)}} >
                <div style={{borderRight: '0.5px solid'}}>  
                    <img src={`${apiUrl}/dr_uploads/${doctor.photo}`} className="cardover"/>
                </div> 
                <div style={{marginLeft: '1rem'}}>                            
                    <h4><b>Dr.{doctor.drname}{doctor.quali}</b></h4>
                    <h6 ><p className="line-height">{doctor.spec}</p>
                    <p className="line-height"><b>Reg. No.</b> {doctor.regno},      <b>Know Language:</b> {doctor.lang}</p>
                    <p className="line-height"><b>Phone:</b> {doctor.phone2} <b>E-Mail:</b> {doctor.email}</p>
                    <p className="line-height"><b>About me:</b> {doctor.about}</p></h6>
                </div>
            </div>
            
        </Col>
    })

    const showFilteredResults = (filters) => {
        const variables = {
            skip: 0,
            limit: Limit,
            filters: filters
        }
        getDoctors(variables)
        setSkip(0)
    }

    const handleFilters = (filters, category) => {
        const newFilters = { Filters }
        newFilters[category] = filters
        // console.log(newFilters)
        showFilteredResults(newFilters)
        setFilters(newFilters)
    }

    const updateSearchTerms = (newSearchTerm) => {
        const variables = {
            skip: 0,
            limit: Limit,
            filters: Filters,
            searchTerm: newSearchTerm
        }
        setSkip(0)
        setSearchTerms(newSearchTerm)
        getDoctors(variables)
    }

    return (
        <div>
            {/* Filter  */}
            <Row gutter={[16, 16]}>
                <Col lg={12} xs={24} >
                    <CheckBox
                        list={Language}
                        handleFilters={filters => handleFilters(filters, "lang")}
                    />
                </Col>
                <Col lg={12} xs={24}>
                    <RadioBox
                        list={Hospital}
                        handleFilters={filters => handleFilters(filters, "hospital")}
                    />
                </Col>
            </Row>

            {/* Search  */}
            <div style={{ display: 'flex', justifyContent: 'flex-end', margin: '1rem auto' }}>
                <SearchFeature
                    refreshFunction={updateSearchTerms} />
            </div>
            {Doctors.length === 0 ?
                <div style={{ display: 'flex', height: '300px', justifyContent: 'center', alignItems: 'center' }}>
                    <h2>No Doctors yet...</h2>
                </div> :
                <div>
                    <Row gutter={[16, 16]}>
                        {renderCards}
                    </Row>
                </div>
            }
            <br /><br />
            

            {PostSize >= Limit &&
                <div style={{ display: 'flex', justifyContent: 'center' }}>
                    
                    <Button type="primary" shape="round" size='large' onClick={onLoadMore}> Load More </Button>
                </div>
            }
        </div>
    )
}

export default withRouter(Search_AppFrom);