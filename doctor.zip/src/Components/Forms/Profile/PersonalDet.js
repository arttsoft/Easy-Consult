import React, { Component } from 'react'
import Image_Upload from '../../../others/Image_Upload';
import axios from 'axios';
import { apiUrl } from "../../../others/config";

export default class PersonalDet extends Component {
    state = {
        data: {
          photo: '',
          proof_f: '',
          proof_b: ''
        },
        errors: {}
      };
    
      onSubmit = e => {
        e.preventDefault();
        const errors = this.validate(this.state.data);
        this.setState({ errors });
        if (Object.keys(errors).length === 0) {
          this.setState({ loading: true });
          this.props.submit(this.state.data);
        }
      };

      validate = data => {
        const errors = {};

        if(data.photo === '' || data.photo === undefined ){
          errors.photo = "Invalid Image"
          data.photo="."
        }
         if(data.proof_f === '' || data.proof_f === undefined ){
          errors.proof_f = "Invalid Image"
          data.photo="."
         }
         if(data.proof_b === '' || data.proof_b === undefined ){
          errors.proof_b = "Invalid Image"
         }
    
        return errors;
      };

      file_photo = (e)=>{                   
        const formData = new FormData();  
        formData.append("myImage", e);
        const config = {
          headers: {
            "content-type": "multipart/form-data"
          }
        };
        // console.log('-- RESPONSE --', formData)
        axios.post(`${apiUrl}/api/doctor/upload`,formData,config)
        .then(response =>{
            // console.log('-- RESPONSE --', response.data.imgpath)             
            this.setState( { data: {...this.state.data, photo: response.data.imgpath} })    
        })
        .catch(err =>{
            console.log('-- err --',err)
        })        
        //this.setState( { data: {...this.state.data, photo: e} })        
      }
      file_proof_f = (e)=>{ 
        const formData = new FormData();  
        formData.append("myImage", e);
        const config = {
          headers: {
            "content-type": "multipart/form-data"
          }
        };
        axios.post(`${apiUrl}/api/doctor/upload`,formData,config)
        .then(response =>{
            // console.log('-- RESPONSE --', response.data.imgpath)             
            this.setState( { data: {...this.state.data, proof_f: response.data.imgpath} })    
        })
        .catch(err =>{
            console.log('-- err --',err)
        })  
        //this.setState( { data: {...this.state.data, proof_f: e} }) 
      }
      file_proof_b = (e)=>{  
        const formData = new FormData();  
        formData.append("myImage", e);
        const config = {
          headers: {
            "content-type": "multipart/form-data"
          }
        };
        axios.post(`${apiUrl}/api/doctor/upload`,formData,config)
        .then(response =>{
            // console.log('-- RESPONSE --', response.data.imgpath)             
            this.setState( { data: {...this.state.data, proof_b: response.data.imgpath} })    
        })
        .catch(err =>{
            console.log('-- err --',err)
        }) 
       // this.setState( { data: {...this.state.data, proof_b: e} }) 
      }

    render() {
        const { data, errors } = this.state;

        return (
            <div>
                <div className="form-group">
                    <label style={{fontWeight:700}}>Upload Your Photo</label>
                    <Image_Upload onFileChange={this.file_photo} value={data.file_photo} />
                    <div className="invalid-feedback">{errors.file_photo}</div>
                </div>

                <div className="form-group">
                    <label style={{fontWeight:700}}>Upload ID Proof Front (with Photo and Address)</label>
                    <Image_Upload onFileChange={this.file_proof_f} value={data.proof_f} />      
                    <div className="invalid-feedback">{errors.file_photo_f}</div>
                </div>

                <div className="form-group">
                    <label style={{fontWeight:700}}>Upload ID Proof Back</label>
                    <Image_Upload onFileChange={this.file_proof_b} value={data.file_proof_b} /> 
                    <div className="invalid-feedback">{errors.file_photo_b}</div>
                </div>

                <button type="submit" className="btn btn-primary btn-block" onClick={this.onSubmit}>
                    Save
                </button>
            </div>
        )
    }
}
