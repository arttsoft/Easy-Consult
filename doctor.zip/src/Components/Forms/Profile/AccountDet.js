import React from 'react'

export default function AccountDet() {
    return (
        <div>
            AccountDet
        </div>
    )
}
