import React from 'react'

export default function Qulification() {
    return (
        <div>
            Qulification
        </div>
    )
}
