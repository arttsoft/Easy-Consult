import React from 'react'

export default function PrimaryDetails() {
    return (
        <div>
            PrimaryDetails
        </div>
    )
}
