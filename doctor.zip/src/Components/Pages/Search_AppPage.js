import React, { Component } from 'react';
import SearchAppForm from '../Forms/Search_AppFrom';

class Search_AppPage extends Component {


  render() {
   // console.log('***********',this.state.mydata); col-sm-4
    return (
      <div className="row container-fluid">
          <div className="container-fluid col-sm-8">
              <h2 className="card-header text-center" style={{backgroundColor: "red", color: "white"}} >Search Doctor</h2>
              <div className="card-body" style={{backgroundColor:'#fceded', height:'39rem', overflowY: 'scroll'}}>
                <SearchAppForm />
              </div>
          </div>
      </div>
    );
  }
}

export default Search_AppPage;