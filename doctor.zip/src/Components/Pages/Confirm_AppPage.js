import React, { Component } from 'react';
import ConfirmAppForm from '../Forms/Confirm_AppFrom';

class Confirm_AppPage extends Component {
  
  render() {
    return (
      <div className="row container-fluid">
          <div className="container-fluid col-sm-8">
              <h2 className="card-header text-center" style={{backgroundColor: "red", color: "white"}} >Confirm Appointment</h2>
              <div className="card-body" style={{backgroundColor:'#fceded', height:'39rem', overflowY: 'scroll'}}>
                <ConfirmAppForm DoctorID={this.props.location.DoctorID}/>
              </div>
          </div>
      </div>
    );
  }
}

export default Confirm_AppPage;