import React from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import LoginForm from "../Forms/LoginForm";
import { login } from "../../actions/auth";

class LoginPage extends React.Component {
  submit = data =>
    this.props.login(data).then(() => this.props.history.push("/dashboard"));

  render() {
    return (
      <div>
        <div className="container" style={{ height: "85vh" }}>
          <div className="row align-items-center" style={{ height: "85vh" }}>
            <div className="col col-xs-12 col-sm-8 offset-sm-2 col-lg-6 offset-lg-3">
              <div className="card cardbodyMager">
                {/* <h2 className="card-header" style={{backgroundColor: "red", color: "white"} >Welcome Back!</h2> */}
                <h2 className="card-header text-center" 
                    style={{backgroundColor: "blue", color: "white"}} >
                      <b>Welcome Doctor!</b></h2>
                <div className="card-body">
                  <LoginForm submit={this.submit} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

LoginPage.propTypes = {
  history: PropTypes.shape({
    push: PropTypes.func.isRequired
  }).isRequired,
  login: PropTypes.func.isRequired
};

export default connect(null, { login })(LoginPage);
