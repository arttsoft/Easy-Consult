import React from "react";
import ProfileForm from "../Forms/ProfileForm";

const SignupPage = () => (
  <div className="clientform">
    <div className="container" style={{ height: "85vh" }}>
          <div className="row align-items-center" style={{ height: "85vh" }}>
            <div className="col-xs-6 col-sm-12 col-lg-6 offset-lg-3 offset-xs-6">
              <div className="card cardbodyMager">
                {/* <h2 className="card-header" style={{backgroundColor: "red", color: "white"} >Welcome Back!</h2> */}
                <h2 className="card-header text-center" 
                    style={{backgroundColor: "blue", color: "white"}} >
                      <b>Profile Update</b></h2>
                <div className="card-body">
                  <ProfileForm />
                </div>
              </div>
            </div>
          </div>
        </div>
  </div>
);

export default SignupPage;
