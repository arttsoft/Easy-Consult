import React from 'react';
// import axios from 'axios';
import {Table, Button} from 'antd';

export default function App_Table(props) {
    // console.log(props.dataSource)
    // const [state, setState] = useState();

    const columns = [
        {
          title: 'Time',
          dataIndex: 'time',
          key: 'time',
          // render: text => <a>{text}</a>,
        },
        {
          title: 'Action',
          key: 'action',
          render: (text, record) => (
            <Button onClick={() => handleDelete(record)}
                color="secondary" >Delete</Button>
          ),
        },
      ];
      
    

    const handleDelete = record => {
        props.parentCallback(record.key)
      };

    return (
        <div> 
            <Table columns={columns} dataSource={props.dataSource} />
        </div>
    )
}
