import React from "react";
import PropTypes from "prop-types";

import gravatarUrl from "../../Image/Logout.png";
import { connect } from "react-redux";
import Logo from "../../Image/Logo.png"
import * as actions from "../../actions/auth";
import { setLocale } from "../../actions/locale";
import { Navbar, Nav } from "react-bootstrap"

class TopNavigation extends React.Component {
  state = {
    isOpen: false
  };

  toggle = () => this.setState({ isOpen: !this.state.isOpen });

  render() {
    const { logout } = this.props;

    return (
      // {user.username}
        <Navbar collapseOnSelect expand="lg" variant="dark" className="navcolor">
          <Navbar.Brand  href="/dashboard">
            <img className="navlogo d-inline-block align-top" src={Logo}  
                   alt="React Bootstrap logo" />
            </Navbar.Brand>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse  id="responsive-navbar-nav">
            <Nav className="mr-auto" />
            <Nav className="h5">            
              {/* <Nav.Link className="navlink" style={{color: "white"}} href="/app_book">Appointment</Nav.Link> */}
              {/* <Nav.Link className="navlink" style={{color: "white"}} href="/consult">Consulting</Nav.Link> */}
              <Nav.Link className="navlink" style={{color: "white"}} href="/profile">Profile</Nav.Link>
              <Nav.Link onClick={() => logout()}>
                <img className="navlink navicon d-inline-block align-top" src={ gravatarUrl }
                    alt="React Bootstrap logo" />
              </Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Navbar>

      // <Navbar expand="sm" color="black">
      //   <NavbarBrand tag={RouterNavLink} activeClassName="active" to="/">
      //     <img src={Logo} alt="Easyconsult" width="120" height="40" />
      //     {/* <Image src={Logo} style={width=100, height=100}/> */}
      //   </NavbarBrand>
      //   <NavbarToggler onClick={this.toggle} />
      //   <Collapse isOpen={this.state.isOpen} navbar>
      //     <Nav navbar>
      //       <NavItem>
      //         <NavLink
      //           tag={RouterNavLink}
      //           activeClassName="active"
      //           to="/dashboard"
      //         >
      //           <FormattedMessage
      //             id="nav.dashboard"
      //             defaultMessage="Dashboard"
      //           />
      //         </NavLink>
      //       </NavItem>
      //       <NavItem>
      //         <NavLink
      //           tag={RouterNavLink}
      //           activeClassName="active"
      //           to="/characters"
      //         >
      //           <FormattedMessage
      //             id="nav.characters"
      //             defaultMessage="My Characters"
      //           />
      //         </NavLink>
      //       </NavItem>
      //     </Nav>
      //     <Nav className="ml-auto" navbar>
      //       {/* <a role="button" onClick={() => this.props.setLocale("en")}>
      //         EN
      //       </a>{" "}
      //       |
      //       <a role="button" onClick={() => this.props.setLocale("ru")}>
      //         RU
      //       </a> */}
      //       <UncontrolledDropdown nav>
      //         <DropdownToggle nav>
      //            {user.username}
      //         </DropdownToggle>
      //         <DropdownMenu right>
      //           <DropdownItem>My Account</DropdownItem>
      //           <DropdownItem divider />
      //           <DropdownItem onClick={() => logout()}>Logout</DropdownItem>
      //         </DropdownMenu>
      //       </UncontrolledDropdown>
      //     </Nav>
      //   </Collapse>
      // </Navbar>
      
    );
  }
}

TopNavigation.propTypes = {
  user: PropTypes.shape({
    email: PropTypes.string.isRequired
  }).isRequired,
  logout: PropTypes.func.isRequired,
  setLocale: PropTypes.func.isRequired
};

function mapStateToProps(state) {
  return {
    user: state.user
  };
}

export default connect(
  mapStateToProps,
  { logout: actions.logout, setLocale },
  null,
  {
    pure: false
  }
)(TopNavigation);
